package com.rest.services.dto;

import java.util.List;

public class ProductDetails {
	
	private int noofIetms;
	
	List<Product> product;

	public int getNoofIetms() {
		return noofIetms;
	}

	public void setNoofIetms(int noofIetms) {
		this.noofIetms = noofIetms;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "ProductDetails [noofIetms=" + noofIetms + ", product=" + product + "]";
	}
	
			

	}
