package com.rest.services.dto;

public class UserRequest {
	private String email;
	private String uname;
	private String pwd;
	private String gender;
	private double contact;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public double getContact() {
		return contact;
	}

	public void setContact(double contact) {
		this.contact = contact;
	}

	@Override
	public String toString() {
		return "UserDetails [email=" + email + ", uname=" + uname + ", pwd=" + pwd + ", gender=" + gender + ", contact="
				+ contact + "]";
	}
	


}
