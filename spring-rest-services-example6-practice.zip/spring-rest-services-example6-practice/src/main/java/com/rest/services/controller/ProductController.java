package com.rest.services.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rest.services.dto.Product;
import com.rest.services.dto.ProductDetails;

@RestController
public class ProductController {
	
	
	@PostMapping("/products/details")
	public String createProduct(@RequestBody Product req)
	{
		System.out.println("Your  json payload" +req);
		
		return "succes";
	}
	
	@PostMapping("/load/products")
	public String createArray(@RequestBody ProductDetails name)
	{
		System.out.println("Yuor details : " + name);
		
		return "Preeti doing assignment successfully";
	}
	
	

}
