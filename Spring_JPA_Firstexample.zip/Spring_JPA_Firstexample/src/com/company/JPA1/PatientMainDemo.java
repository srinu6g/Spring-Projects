package com.company.JPA1;

import java.util.Optional;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.company.JPA.SpringJpaConfiguration;

public class PatientMainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(SpringJpaConfiguration.class);
		context.refresh();
		
		PatientOperations pa=context.getBean(PatientOperations.class);
		//pa.patientDetails();
		//pa.addMorePatients();
		//pa.updatePatientDetails();
		//pa.deletePatientDetails("ajay@gmail.com");
	Patient p=(Patient)	pa.getPatentDetails("hitesh@gmail.com");
	System.out.println(p);
		

	}

}
