package com.company.JPA1;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PatientOperations {
	
	@Autowired
	PatientRepository repo;
	
	
	/// Single patient details
	
	public void patientDetails()
	{
		Patient p=new Patient();
		p.setEmail("sriivas@gmail.com");
		p.setGender("Male");
		p.setMobileNumber(45639495);
		p.setPatientAge(24);
		p.setPatientName("srini");
		
		
		repo.save(p);
		
		
	}
	
	// Multiple patient details 
	public void addMorePatients()
	{
		Patient p1=new Patient();
		p1.setEmail("sriivas@gmail.com");
		p1.setGender("Male");
		p1.setMobileNumber(45639495);
		p1.setPatientAge(24);
		p1.setPatientName("srini");
		
		
		Patient p2=new Patient();
		p2.setEmail("mani@gmail.com");
		p2.setGender("Male");
		p2.setMobileNumber(8979495);
		p2.setPatientAge(22);
		p2.setPatientName("mani");
		
		Patient p3=new Patient();
		p3.setEmail("hitesh@gmail.com");
		p3.setGender("Male");
		p3.setMobileNumber(9663081);
		p3.setPatientAge(25);
		p3.setPatientName("hitesh");
		
		
		Patient p4=new Patient();
		p4.setEmail("ajay@gmail.com");
		p4.setGender("FEMale");
		p4.setMobileNumber(964095);
		p4.setPatientAge(24);
		p4.setPatientName("ajay");
		
		
		List<Patient> l1=new ArrayList();
		l1.add(p1);
		l1.add(p2);
		
		l1.add(p3);
		
		l1.add(p4);
		
		
		repo.saveAll(l1);
		
		
	}
	
	// update patient detalis
	
	
	public void updatePatientDetails()
	{
		
		Patient p4=new Patient();
		p4.setEmail("ajay@gmail.com");
		p4.setGender("Male");
		p4.setMobileNumber(964095);
		p4.setPatientAge(24);
		p4.setPatientName("ajay");
		
		
		repo.save(p4);
		
	}
	
	
	// retrive the data 
	
	public Patient getPatentDetails(String email)
	{
		return repo.findById(email).get();
	}
	
	// delete single record
	
	 public void deletePatientDetails(String email)
	 {
		 repo.deleteById(email);
	 }
	
	
	

}
