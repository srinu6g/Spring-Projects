package com.company.JPA;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Integer> {
	
	
	// Student is a java class name and id of column in java class return type Integer

}
