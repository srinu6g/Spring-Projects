package com.company.JPA;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StudentFunctionalities {
	
	@Autowired
	StudentRepository repo;
	
	public void addDetails()
	{
		Student s1=new Student();
		s1.setStudentId(101);
		
		s1.setStudentName("hitesh");
		s1.setCourse("Maths");
		s1.setAge(25);
		
		repo.save(s1);
		
		
	}
	
	
	
	

}
