package com.nareshit;

import org.springframework.beans.factory.*;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class SpringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//System.out.println("Hello everyone");
		
		BeanFactory container=new FileSystemXmlApplicationContext("C:\\Users\\manik\\eclipse-workspace\\Spring_core_example\\spring-beans.xml");
		
				Object obj=container.getBean("emp");
				Employee emp= (Employee)obj;
				System.out.println("First employee details:");
				System.out.println(emp.getEmpId());
				System.out.println(emp.getEmpName());
				//System.out.println(emp.empDetals());
				System.out.println("second emp object details: ");
				Object obj1=container.getBean("emp1");
				Employee emp1= (Employee)obj1;
				System.out.println(emp1.getEmpId());
				System.out.println(emp1.getEmpName());
				
				
				
				
	}

}
