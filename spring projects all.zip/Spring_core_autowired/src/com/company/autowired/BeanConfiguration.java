package com.company.autowired;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.*")
public class BeanConfiguration {
	
	
	 @Autowired
	  private ApplicationContext context;

	    @Bean("emp")
	    public Employee getEmployeeDetails() {
	        Employee e = new Employee();
	        e.setEmpId(101);
	        e.setEmpName("praveen");

	        // Retrieve Address bean from the Spring context
	        Address adr = (Address)context.getBean("home");
	        e.setAddress(adr);

	        return e;
	    }
	    @Bean("guntur")
	    public Address getAddress() {
	        Address adr = new Address();
	        adr.setCity("Guntur");
	        adr.setPincode(10165);
	        return adr;
	    }
		
	


}
