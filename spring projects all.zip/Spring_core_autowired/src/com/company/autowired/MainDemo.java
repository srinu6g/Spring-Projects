package com.company.autowired;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext factory=new AnnotationConfigApplicationContext();
		factory.register(BeanConfiguration.class);
		factory.refresh();
		
	/*	Employee emp1=(Employee)factory.getBean(Employee.class);
		System.out.println(emp1);
		System.out.println(emp1.getEmpId());
		System.out.println(emp1.getEmpName());
		System.out.println(emp1.getAddress().getCity());
		System.out.println(emp1.getAddress().getPincode()); */
		
		
		Employee emp1=(Employee)factory.getBean("emp");	
		System.out.println(emp1);
		//System.out.println(emp1.getAddress().getCity());
		//Address adr=(Address)emp1.getAddress();
		
	}

}
