package com.company.constricor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context= new FileSystemXmlApplicationContext("C:\\Users\\manik\\eclipse-workspace\\Spring_Core_ConstructorInjection_Practice\\beans.xml");
		 Product p1=(Product)context.getBean("product1");
		 System.out.println(p1);
			 Product p2=(Product)context.getBean("product1");
			 System.out.println(p2);
		 Product p6=(Product)context.getBean("product1");
		 System.out.println(p6);
		 Product p8=(Product)context.getBean("product1");
		 System.out.println(p8);
		 Product p3=(Product)context.getBean("product1");
		 System.out.println(p3);
		 Product p9=(Product)context.getBean("product1");
		 System.out.println(p9);
		 Product p7=(Product)context.getBean("product1");
		 System.out.println(p7);
			
		
		
	/*	System.out.println("***************888888888888************************88");
		
		System.out.println("Order class Details ");
		
		Order order=(Order)context.getBean("order1");
		System.out.println(order.getItems());
		System.out.println(order.getOrderId());
		System.out.println(order.getProd().getPid());
		System.out.println(order.getProd().getpName());*/
		
	}

}
