

package com.company.constricor;

public class Order {
	
	private int orderId;
	private String items;
	
	private Product prod;
	
	public Product getProd() {
		return prod;
	}
	public void setProd(Product prod) {
		this.prod = prod;
	}
	public Order(int orderId, String items, Product prod) {
		super();
		this.orderId = orderId;
		this.items = items;
		this.prod = prod;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getItems() {
		return items;
	}
	public void setItems(String items) {
		this.items = items;
	}
	
	

}
