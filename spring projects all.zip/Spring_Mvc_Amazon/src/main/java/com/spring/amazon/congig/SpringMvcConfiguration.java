package com.spring.amazon.congig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@ComponentScan("com.*")
@Configuration
@EnableWebMvc// this annotation equals to extends WebMvcConfigurationSupport this class
public class SpringMvcConfiguration extends WebMvcConfigurationSupport {
	
	@Bean
	public InternalResourceViewResolver internalViewResolver()
	{
		InternalResourceViewResolver viewResolver =new InternalResourceViewResolver();
		viewResolver.setPrefix("/WEB-INF/views/");
		viewResolver.setSuffix(".jsp");
		
		return viewResolver;
	}
	
	

}
