package com.spring.amazon.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.amazon.user.entity.UserInformation;


public interface UserRepository extends JpaRepository<UserInformation,String> {

}
