package com.spring.amazon.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.amazon.user.dto.UserRequest;
import com.spring.amazon.user.entity.UserInformation;
import com.spring.amazon.user.repository.UserRepository;

@Service // @service annotation is derived from @Component annotation 
// to write business logics 
// it is one of stereotype annotation
public class UserService {
	
	// we can perform dependency injection repository layer injecting with service layer
	@Autowired
	UserRepository repo;
	
	// receving data from controller layer  and forward to repository latyer
	public String createUser(UserRequest request)
	{
		System.out.println(request);
		
		//Map/transfer data from request to Entity Object 
		
		UserInformation information=new UserInformation();
		information.setEmail(request.getEmail());
		information.setName(request.getName());
		information.setPassword(request.getPassword());
		information.setContact(request.getContact());
		
		
		repo.save(information);
		
		
		
		
		//TODO forward this data to repository layer that will discuss later
		return "User submitted succesfully";
		
	}

}
