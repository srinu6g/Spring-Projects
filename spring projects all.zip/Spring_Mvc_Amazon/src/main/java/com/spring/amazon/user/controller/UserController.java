package com.spring.amazon.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.spring.amazon.user.dto.UserRequest;
import com.spring.amazon.user.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	
	// now am integrating controller layer with service layer by usin DI
	@Autowired
	UserService userService;
	
	@RequestMapping(path = "/create" , method = RequestMethod.GET)
	@ResponseBody
	public String createUserDetails()
	{
		System.out.println("User controller created successfully");
		 // TODO actually request come from browser means like html,jsp file
		// but time being user request class craeted and pass data directly 
		
		UserRequest request=new UserRequest("Srinivas rao","srinivas124","vas@gmail.com","+915243234");
		String result=userService.createUser(request);
		
		// TODO forward these request to service layer
		return result;
		
	}
	// discussing about view resolver  :: is a interface  to dicuss main about jsp,html file location
	//@ResponseBody talks about mainly in restful api
	// if you are not giving @ResponseBody in given below method its consider as jsp file name
	// when ever hit the url/endpoint it will check hello.jsp is available or not 
	// in that particular location src->main>java->webapp>WEB-INF>Create new folder (Views)->hello.jsp file
	/*
	 * @Bean
	public InternalResourceViewResolver internalViewResolver()
	{
		InternalResourceViewResolver viewResolver =new InternalResourceViewResolver();
		viewResolver.setPrefix("/WEB-INF/views/");
		viewResolver.setSuffix(".jsp");
		
		return viewResolver;
	}
	
	 
	// for example if you giving @Responsebody then its consider as a mesage hello print in yor browser
	
	@RequestMapping("/hi")
	//@ResponseBody
	public String sayHello()
	{
		
		return "hello";
	}*/

}

/* service class as A class 
 * controller class as B class
 *  class A
 *  {
 *  createUser(UserRequset req)
 *  {
 *  }
 *  
 *  }
 *  
 *  how to achieve A class method in B class
 *  
 *  class B
 *  {
 *  		A a=new A() ;
 *  * 			a.createUser(); 
 *  }
 *  but in spring mvc /framework Uservice object created by container itself 
 *  only when performing DI @Autowired
 *  userService.createUser();
 *  
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
