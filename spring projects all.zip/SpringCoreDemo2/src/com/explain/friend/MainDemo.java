package com.explain.friend;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// creating container object
		//BeanFactory factory=new FileSystemXmlApplicationContext();
		
			BeanFactory factory=new FileSystemXmlApplicationContext("C:\\Users\\manik\\eclipse-workspace\\SpringCoreDemo2\\Demo.xml");
			
			
			
		/*	Address address=(Address)factory.getBean("rama");
			// getBean("beanid")
			System.out.println("*******Address class Details ***************");
			System.out.println(address);
			System.out.println(address.getCity());
			System.out.println(address.getPincode());
			System.out.println(address.getItems());
			System.out.println(address.getItems().size());
			System.out.println(address.getNumbers());
			System.out.println(address.getNumbers().size());
			
			
		
			/**************************************************/
			/*
			 * Object obj=	factory.getBean("emp9");
				
				Employee e6=(Employee)obj;
				
			 
				
			Employee emp=(Employee)		factory.getBean("emp9");
			System.out.println(emp);
			System.out.println(emp.getEmployeeId());
			System.out.println(emp.getEmpName());
			System.out.println(emp.getSalary());
		Set s=emp.getNames();
		System.out.println(s);
		
	//System.out.println(emp.getMovieHero());
		Map <String,String> m=emp.getMovieHero();
		System.out.println(m);
		
		//Duplicates keys are not allowed ,but values are duplicates allowed */
			
	Employee empl=(Employee)factory.getBean("emp6");
	System.out.println(empl.getEmployeeId());	
	System.out.println(empl.getEmpName());
	System.out.println(empl.getSalary())
	;
	System.out.println(empl.getAdd().getCity());
	System.out.println(empl.getAdd().getPincode());
			
		// emp8 person belongs to hyd location
	System.out.println("******************************************");
	
	Employee emp22=(Employee)factory.getBean("emp8");
	System.out.println(emp22.getEmployeeId());	
	System.out.println(emp22.getEmpName());
	System.out.println(emp22.getSalary())
	;
	System.out.println(emp22.getAdd().getCity());
	System.out.println(emp22.getAdd().getPincode());
	
			
			
	}

}
