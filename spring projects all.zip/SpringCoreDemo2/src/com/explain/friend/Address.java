package com.explain.friend;

import java.util.List;
import java.util.Set;

public class Address {
	// properties is nothing but varaibles and methods
	private int pincode;
	private String city;
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	
	
		

}
