package com.naresh.field;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class FieldLabelAutowiredDemo {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(FieldPropertyUsingautowired.class);
		context.refresh();
		
System.out.println("******Address details first person*******");
		Address adrs=(Address)context.getBean("address1");
		System.out.println(adrs);
		System.out.println(adrs.getCity());
		System.out.println(adrs.getPincode());
		
		System.out.println("******Address details second person*******");
		Address adrs2=(Address)context.getBean("address2");
		System.out.println(adrs2);
		System.out.println(adrs2.getCity());
		System.out.println(adrs2.getPincode());
		
		System.out.println("******emplyee 1 details ****** Injecting Address values by using @Autowired and @Qualifier");
		Employee employee=(Employee)context.getBean("emp1");
		System.out.println(employee);
		System.out.println(employee.getEmpName());
		System.out.println(employee.getAddress().getCity());
		System.out.println(employee.getAddress().getPincode());
	
		
		
		
		

	}

}
