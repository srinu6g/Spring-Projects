package com.naresh.field;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@ComponentScan("com.naresh.*")
@Configuration
public class FieldPropertyUsingautowired {
	@Bean(name="address2")
	public Address getAddress()
	{
		Address a=new Address();
		a.setCity("HYD");
		a.setPincode(34522);
		return a;
	}

}
