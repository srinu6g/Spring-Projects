package com.company.JPA;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface StudentRepository extends JpaRepository<Student, Integer> {
	
	
	// Student is a java class name and id of column in java class return type Integer

	// custom Query methods 
	
	// Req1 :: getting data/record by using Studentname
	
	
	//public List<Student> findByjava proprtyname(parameter return type)
	public List<Student> findBystudentName(String sname);
	
	// Req2 :: getting data/record by using age

		public List<Student> findByage(int age);
		
		
		// req3  i want to retrive/getting based on age and sname
		
		public List<Student> findByStudentNameAndAge(String sname,int age);	
		
		
		//nativeQueey,JPQL ,paging ang sorting 
		
	/*	@Query(value = "SELECT * FROM student",nativeQuery = true)
		public List<Student> gettingAll();
		
		@Query(value = "SELECT sid FROM student",nativeQuery = true)
		public List<Integer> gettingAllStudentId();
		
		@Query(value = "SELECT sname FROM student",nativeQuery = true)
		public List<String> gettingAllStudentNames();
		
		@Query(value = "SELECT sname FROM student where sid=?1",nativeQuery = true)
		public List<String> gettingAllStudentNamesBasedonStudentId(int studentId);
		
		@Query(value = "SELECT sname FROM student where sid=?1 and age=?2",nativeQuery = true)
		public List<String> gettingAllStudentNamesBasedonStudentIdAndAge(int studentId,int age);
		
		*/
		// based on student name getting record using param
		@Query(value = "SELECT * FROM student where sname=:studentName",nativeQuery = true)
		public List<Student> gettingAllStudentId(@Param ("studentName") String sname);
		
		// based on studentname and age getting record using param
		
		@Query(value = "SELECT * FROM student where sname=:studentName and age=:age",nativeQuery = true)
		public List<Student> gettingrecordsbasedonsnameandAge(@Param ("studentName") String sname,
				@Param("age") int age
				);
		
		
			
}
