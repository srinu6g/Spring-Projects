package com.company.JPA;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;

@Component
public class StudentFunctionalities {
	
	@Autowired
	StudentRepository repo;
	
	//REq 1 ::  Add one student deatils
	
	/*public void addStudent()
	{
		Student s1=new Student();
		
			s1.setAge(25);
			s1.setCourse("java");
			s1.setStudentId(101);
			s1.setStudentName("srinivas");
			
			repo.save(s1);
		
	}
	
	// Req i want multiple student data at a time 10 student
	
	public void AddMoreStudentDetails()
	{
		Student s2=new Student();
		s2.setAge(24);
		s2.setCourse("Spring");
		s2.setStudentId(102);
		s2.setStudentName("Hitesh");
		
		Student s3=new Student();
		s3.setAge(29);
		s3.setCourse("SpringBoot");
		s3.setStudentId(103);
		s3.setStudentName("Lakshmi");
		
		Student s4=new Student();
		s4.setAge(24);
		s4.setCourse("HTML");
		s4.setStudentId(105);
		s4.setStudentName("Anu");
		
		Student s5=new Student();
		s5.setAge(45);
		s5.setCourse("SQL");
		s5.setStudentId(192);
		s5.setStudentName("rajavani");
		
		Student s6=new Student();
		s6.setAge(24);
		s6.setCourse("Oracle");
		s6.setStudentId(120);
		s6.setStudentName("preeti");
		
		
		List<Student> l2=new ArrayList<>();
		l2.add(s2);
		l2.add(s3);
		l2.add(s4);
		l2.add(s5);
		l2.add(s6);	
		
		repo.saveAll(l2);
	} 
	
	// REq 3 I  want to update my sid is 192 to 105
	
	public void updateStudent()
	{
		
		Student s6=new Student();
		s6.setAge(24);
		s6.setCourse("English");
		s6.setStudentId(109);
		s6.setStudentName("Deva");
		
		repo.save(s6)
;		
	}
	
	// fetchig the records
	
	// based on primary key columns and non primary key columns 
	
	public Student fetchingStudentDetails()
	{
		return repo.findById(102).get();
	}
	
	// deleting a record
	
	public void deleteRecord()
	{
		repo.deleteById(109);
	}*/
	
	
	// now talking about custom query parameters 
	// we can achive/retrive dattabase information via non primary key columns 
	
	public List<Student> gettingDetailsbasedOnStudentName()
	{
		return repo.findBystudentName("Hitesh");
	}
	

	public List<Student> gettingDetailsbasedOnAge()
	{
		return repo.findByage(24);
	}
	// // req3  i want to retrive/getting based on age and sname
	
	
	public List<Student> gettingDetailsbasedOnStudentNameAndage()
	{
		return repo.findByStudentNameAndAge("preeti",24);
	}
	
	// native sql 
	
	// know i want to retrive all student datas
	
	/*public List<Student> fetchingAllStudents()
	{
		return repo.gettingAll();
	}
	// know i want to retrive all studentid  data
	public List<Integer> fetchingAllStudentsids()
	{
		return repo.gettingAllStudentId();
	}
	
	// know i want to retrive all studentNames  data
		public List<String> fetchingAllStudentsNames()
		{
			return repo.gettingAllStudentNames();
		}
		
		
	// native sql index based 
		
		/*public List<String> fetchingAllStudentsNameBasedonStudentId()
		{
			return repo.gettingAllStudentNamesBasedonStudentId(102);
		}
			
		public List<String> fetchingAllStudentsNameBasedonStudentIdandAge()
		{
			return repo.gettingAllStudentNamesBasedonStudentIdAndAge(105,24);
		}*/
		
		// nativeSQL param based annottaion
	
	public List<Student> fetchingAllStudentsNameBasedonStudentId()
	{
		return repo.gettingAllStudentId("Anu");
	}
	public List<Student> fetchingAllStudentsNameandAge()
	{
		return repo.gettingrecordsbasedonsnameandAge("Anu",24);
	}
	
	//Sorting and pagination all are pre defined methods vailable so directly use in functionality class
	
	// based on sname i want desc order
	
	public List<Student> gettingDetailsBasedOnSorting()
	{
	      return repo.findAll(Sort.by(Direction.DESC,"studentName"));
	}
	public List<Student> gettingDetailsBasedOnSortingBystudentNames()
	{
	      return repo.findAll(Sort.by("studentName"));
	}
	
	
	// pagination
	
	
	public void gettingRecordsByusingPagination()
	{
		PageRequest req= PageRequest.of(1, 3);
		
		System.out.println("You are second pagination :");
		List<Student> s1=(List<Student>) repo.findAll(req).getContent();
		s1.stream().forEach(System.out::println);
	
		
	}
	public void gettingRecordsByusingPaginationAndSorting()
	{
		PageRequest req1= PageRequest.of(1, 3,Sort.by("studentName"));
		System.out.println("You are second pagination and followed by sorting :");
		//System.out.println("You are second pagination :");
		List<Student> s1=(List<Student>) repo.findAll(req1).getContent();
		s1.stream().forEach(System.out::println);
	
		
	}
	
		
}
