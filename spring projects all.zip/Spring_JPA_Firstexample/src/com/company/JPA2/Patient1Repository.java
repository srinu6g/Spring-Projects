package com.company.JPA2;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface Patient1Repository extends JpaRepository<Patient1, String> {

	
	// getting patient age
	List<Patient1> findByAge(int age);
//getting patient age and gender
	
	List<Patient1> findByAgeAndGender(int age, String gender);
	
	
	//  i want retruve all patienbt details
	
	@Query(value="SELECT * FROM patient_details",nativeQuery = true)
	List<Patient1> findAllDetails();
	
	
	// index parameter 
	@Query(value="SELECT * FROM patient_details where age=?1",nativeQuery = true)
	List<Patient1> findAllDetailsByAge(int age);
	
	@Query(value="SELECT * FROM patient_details where age=?1 and gender=?2",nativeQuery = true)
	List<Patient1> findAllDetailsByAgeAndGender(int age,String gender);
	// named query
	
	
	@Query(value="SELECT * FROM patient_details where email=:email",nativeQuery = true)
	List<Patient1> findAllDetailsByEmail(@Param("email") String email);
	
	

}
