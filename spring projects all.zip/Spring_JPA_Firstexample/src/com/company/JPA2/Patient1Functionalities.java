package com.company.JPA2;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Patient1Functionalities {
	
	@Autowired
	Patient1Repository repo;
	
	// req 1: add single patient details
	public void addPatient1Details()
	{
		Patient1 p1=new Patient1();
		p1.setAge(20);
		p1.setContact(234633);
		p1.setEmail("amma@gmail.com");
		p1.setGender("Female");
		p1.setPname("amma");
		
		repo.save(p1);
	}
	// req 2  adding ,mutiple patient details
	public void addPatient1MoreDetails()
	{
		Patient1 p1=new Patient1();
		p1.setAge(20);
		p1.setContact(234633);
		p1.setEmail("amma@gmail.com");
		p1.setGender("Female");
		p1.setPname("amma");
		
		Patient1 p2=new Patient1();
		p2.setAge(23);
		p2.setContact(2345433);
		p2.setEmail("hitesh@gmail.com");
		p2.setGender("Male");
		p2.setPname("hitesh");
		
		Patient1 p3=new Patient1();
		p3.setAge(25);
		p3.setContact(987433);
		p3.setEmail("Mani@gmail.com");
		p3.setGender("Male");
		p3.setPname("Mani");
		
		Patient1 p4=new Patient1();
		p4.setAge(20);
		p4.setContact(234633);
		p4.setEmail("srinivas@gmail.com");
		p4.setGender("male");
		p4.setPname("srinivas");
		
		Patient1 p5=new Patient1();
		p5.setAge(23);
		p5.setContact(2345433);
		p5.setEmail("anu@gmail.com");
		p5.setGender("Female");
		p5.setPname("anu");
		
		Patient1 p6=new Patient1();
		p6.setAge(25);
		p6.setContact(987433);
		p6.setEmail("Meghana@gmail.com");
		p6.setGender("Female");
		p6.setPname("Meghana");
		
		List<Patient1> l1=Arrays.asList(p1,p2,p3,p4,p5,p6);
		repo.saveAll(l1);
		
	}
	// req 3: update record 
	
	public void updatePatient1Details()
	{
		Patient1 p1=new Patient1();
		p1.setAge(48);
		p1.setContact(234633);
		p1.setEmail("amma@gmail.com");
		p1.setGender("Female");
		p1.setPname("amma");
		
		repo.save(p1);
	}
	// req 4 delete a record
	
	public void deletePatient1Details()
	{
	
	Patient1 p4=new Patient1();
	p4.setAge(20);
	p4.setContact(234633);
	p4.setEmail("srinivas@gmail.com");
	p4.setGender("male");
	p4.setPname("srinivas");
	
	repo.delete(p4);
	}
	
	//req 5  getting patient details based on primary key column
	public Patient1 gettingPatient1Details(String email)
	{
	
	
		return repo.findById(email).get();
	
	}
	// above all methods are pre defined methods 
	// now we are discussing custom query methods 
	
	// req 6 get the details of patient by age 
	
	
	public List<Patient1> gettingPatient1Age(int age)
	{
		List<Patient1>l1= repo.findByAge(age);
		return l1;
	}
	
	//req 7 get the details of patient by age  and gender
	public List<Patient1> gettingPatient1AgeAndGender(int age,String gender)
	{
		List<Patient1>l2= repo.findByAgeAndGender(age,gender);
		return l2;
	}
	
	// native sql queries
	
	public List<Patient1> gettingAllPatients()
	{
		List<Patient1> l2= repo.findAllDetails();
		return l2;
	}
	//index
	public List<Patient1> gettingAllPatientsByAge()
	{
		List<Patient1> l3= repo.findAllDetailsByAge(25);
		return l3;
	}
	
	public List<Patient1> gettingAllPatientsByAgeAndGender()
	{
		List<Patient1> l4= repo.findAllDetailsByAgeAndGender(25,"Male");
		return l4;
	}
	
	public List<Patient1> gettingAllPatientsByEmail()
	{
		List<Patient1> l5= repo.findAllDetailsByEmail("Meghana@gmail.com");
		return l5;
	}
	

}
