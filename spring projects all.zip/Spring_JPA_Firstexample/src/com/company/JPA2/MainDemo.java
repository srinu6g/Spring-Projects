package com.company.JPA2;

import org.hibernate.mapping.List;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(SpringJpaConfiguration.class);
		context.refresh();
		
		Patient1Functionalities pf=context.getBean(Patient1Functionalities.class);
		//pf.addPatient1Details();
		//pf.addPatient1MoreDetails();
		//pf.updatePatient1Details();
		//pf.deletePatient1Details();
	     /* Patient1 p1=pf.gettingPatient1Details("hitesh@gmail.com");
		System.out.println(p1);
		
		java.util.List<Patient1> p1= pf.gettingPatient1Age(25);
		System.out.println(p1);
		

		java.util.List<Patient1> p2= pf.gettingPatient1AgeAndGender(25,"Male");
		System.out.println(p2);
		java.util.List<Patient1> p4= pf.gettingPatient1Age(25);
		System.out.println(p4);
		
		java.util.List<Patient1> p5= pf.gettingAllPatientsByAgeAndGender();
		System.out.println(p5);*/
		
		

		java.util.List<Patient1> p6= pf.gettingAllPatientsByEmail();
		System.out.println(p6);
		
	}

}
