package com.naresh.settetandconst;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class CollectionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new 	AnnotationConfigApplicationContext();
		context.register(SetterAndConstructorConfiguration.class);
		context.refresh();
		
		Company company=(Company)context.getBean(Company.class);
		System.out.println(company);
		System.out.println(company.getEmp());
		
		//if you acess one by one employee objects like [emp1],[emp2],[emp3] in List<Employee>
		
		//using for loop
		
		List<Employee> allEmplyees =company.getEmp();
		
		for(Employee e:allEmplyees)
		{
			System.out.println(e);
		}
				

	}

}
