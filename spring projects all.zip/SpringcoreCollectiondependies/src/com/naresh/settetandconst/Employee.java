package com.naresh.settetandconst;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
//@Primary now am passing employee3 as default that why this (employee1) 
//is in comment becoz more than one default not allowed it willget runtime exceptions 
//say more than one primary available for 3 objects employee1,employee2,employee3
@Component("employee1")
public class Employee {
	
	private int eid;
	private String ename;

	private double salary;
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	//toString() is used to convert objects into a String format
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", salary=" + salary + "]";
	}
	
	

}
