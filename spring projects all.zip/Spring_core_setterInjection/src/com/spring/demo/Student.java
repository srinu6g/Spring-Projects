package com.spring.demo;

import java.util.List;

public class Student {
	
	private int sid;
	private String sname;
	private double marks;
	private char gender;
	private List<String> items;
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("this is constructors :");
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(double marks) {
		this.marks = marks;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public List<String> getItems() {
		return items;
	}
	public void setItems(List<String> items) {
		this.items = items;
	}
	
	
	
	
	
	
}
