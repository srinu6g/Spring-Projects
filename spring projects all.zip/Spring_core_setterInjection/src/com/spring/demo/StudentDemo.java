package com.spring.demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class StudentDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//crerate container by using beanfactory
		
		BeanFactory container=new FileSystemXmlApplicationContext("C:\\Users\\manik\\eclipse-workspace\\Spring_core_setterInjection\\spring-setter.xml");

			Student stu1=(Student)container.getBean("stu1");
			System.out.println("Student details: ");
			System.out.println(stu1.getSid());
			System.out.println(stu1.getSname());
			System.out.println(stu1.getMarks());
			System.out.println(stu1.getGender());
			System.out.println(stu1.getItems());
			
		
	}
	

}
