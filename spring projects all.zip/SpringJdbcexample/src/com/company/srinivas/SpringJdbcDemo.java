package com.company.srinivas;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringJdbcDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(SpringJdbcConfig.class);
		context.refresh();
		
		StudentOperations stu=(StudentOperations)context.getBean(StudentOperations.class);
		
		//stu.addStudentDetails();
		//stu.addStudentDetailsDynamically(102,"srinivas", 26);
		//stu.addDetailsDynamically2(104, "ram",30);
		
		//stu.getStudentDetails();
		stu.getStudentDetailsName();

	}

}
