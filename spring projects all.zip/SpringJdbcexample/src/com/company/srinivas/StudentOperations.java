package com.company.srinivas;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

//@ComponentScan("com.company.srinivas")
@Component
public class StudentOperations {
	
	
	@Autowired
	JdbcTemplate jdbctemplate;
	
	//Add student details throug  sql query
	
	public void addStudentDetails()
	{
		String query="insert into student values(101,'mani',25)";
		jdbctemplate.update(query);
		
		System.out.println("one record inserted ");
	}
	
	
	// add one more record through dynamically
	
	public void addStudentDetailsDynamically(int id,String name,int age)
	{
		
		String query="insert into student values(?,?,?)";
		int c=jdbctemplate.update(query,id,name,age);
		System.out.println("one record inserted dynamically"+c);
		
	}
	
	// dynamically pass one more record
	
	public void addDetailsDynamically2(int id,String name,int age)
	{
		String query="insert into student values(?,?,?)";
		jdbctemplate.update(query, id ,name,age);
		System.out.println("one more added");
		
	}
	
	
	//I want retrive all student details
	
	public void getStudentDetails()
	{
		String query="select * from student";
		
		//List<Student> alldetails=jdbctemplate.query(query, new BeanPropertyRowMapper<Student>Student.class);
		List<Student> allstudents = jdbctemplate.query(query, new BeanPropertyRowMapper<Student>(Student.class));
		allstudents.stream().forEach(System.out::println);
	}
	
	//retrive data based on one column in a table
	
	public void getStudentDetailsName()
	{
		String query="select name from student";
		//List<Map<String, Object>> name=jdbctemplate.queryForList("name");
		//List<Map<String, Object>> student=jdbctemplate.queryForList(query, "name");
		List<String> allStudentNames = jdbctemplate.queryForList(query, String.class);

		allStudentNames.stream().forEach(System.out::println);
		
	}
	


}
