package com.company.autowiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// how to create container 

		ApplicationContext context=new FileSystemXmlApplicationContext("C:\\Users\\manik\\eclipse-workspace\\Spring_Autowiring\\beans.xml");
		
			Gold g=(Gold)context.getBean("gold");
			System.out.println(g);
			g.goldDetails();
	
	
	
	}

}
