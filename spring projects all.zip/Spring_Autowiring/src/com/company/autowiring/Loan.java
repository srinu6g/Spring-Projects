package com.company.autowiring;

public class Loan {
	
	public void loanDetails()
	{
		System.out.println("Loan taken succesfully");
	}

}
