package com.company.autowiring;

public class Gold {
	
	private Loan loan;
	

	public Gold(Loan loan) {
		//super();
		this.loan = loan;
		System.out.println("parameterized consyyrgeg'lgm;l");
	}

	public Loan getLoan() {
		return loan;
	}

	public void setLoan(Loan loan) {
		this.loan = loan;
	}

	@Override
	public String toString() {
		return "Gold [loan=" + loan + "]";
	}
	public void goldDetails()
	{
		loan.loanDetails();
	}

}
