package com.naresh.mani;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringcoreDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//BeanFactory factory=new AnnotationConfigApplicationContext(SpringcoreBeansConfig.class,SpringCoreBeansconfiguration.class);
		//BeanFactory context = new AnnotationConfigApplicationContext(BeansConfiguration.class);
		AnnotationConfigApplicationContext factory=new AnnotationConfigApplicationContext();
		factory.register(SpringcoreBeansConfig.class,SpringCoreBeansconfiguration.class);
		factory.refresh();
		
		Employee e=(Employee)factory.getBean("emp");
		System.out.println("Emp details now getting by default values");
		System.out.println(e.getEmpid());
		System.out.println(e.getEname());
		System.out.println(e.getSal());
		
		System.out.println("Second employee details");
		Employee e1=(Employee)factory.getBean("empl2");
		System.out.println(e1.getEmpid());
		System.out.println(e1.getEname());
		System.out.println(e1.getSal());
		
		System.out.println("Order details");
		Order item=(Order)factory.getBean("order1");
		System.out.println("your order id :"+(item.getId()));
		
		
	}

}
