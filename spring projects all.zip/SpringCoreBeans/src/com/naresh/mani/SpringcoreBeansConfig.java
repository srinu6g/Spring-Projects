package com.naresh.mani;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringcoreBeansConfig {
	@Bean(name="emp2")
	public Employee getEmployeeDetails()
	{
		Employee empl=new Employee(101,"ajay",40000);
		
		return empl;
		
	}
	@Bean(name="empl2")
	public Employee createEmployee()
	{
		Employee emp2=new Employee(101,"hitesh",30000);
		return emp2;
	}
	

}
