package com.naresh.mani;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringCoreBeansconfiguration {
	
	//public 
	@Bean(name="order1")
	public Order getOrderDetails()
	{
		Order order=new Order();
		order.setId(101);
		return order;
	}

}
