package com.jpa.sorting;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.jpa.Mani.SpringJpaConfiguration;

public class SortingMainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(SpringJpaConfiguration.class);
		context.refresh();
		
		SortingOperations ops=	context.getBean(SortingOperations.class);
		//ops.add();
		//ops.addMoreRec();
	//	ops.sortingDemo();
	//	ops.sortingDemo1();
		ops.sortingDemo2();
		
	

	}

}
