package com.jpa.sorting;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SortingRepository extends JpaRepository<OrdersData,Integer> {

}
