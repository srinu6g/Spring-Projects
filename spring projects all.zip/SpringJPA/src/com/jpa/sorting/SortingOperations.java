package com.jpa.sorting;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;

@Component
public class SortingOperations {
	
	@Autowired
	SortingRepository repo;
	public void add()
	{
		
		OrdersData o1=new OrdersData();
		o1.setOrderId(34);
		o1.setCity("guntur");
		o1.setNoOfItems(5);
		o1.setPincode(345324);
		o1.setGender("Male");
		o1.setPrice(500);
		
		repo.save(o1);
	}
	
	public void addMoreRec()
	{
		OrdersData o1=new OrdersData();
		o1.setOrderId(27);
		o1.setCity("guntur");
		o1.setNoOfItems(57);
		o1.setPincode(3445324);
		o1.setGender("FeMale");
		o1.setPrice(200);
		
		OrdersData o2=new OrdersData();
		o2.setOrderId(85);
		o2.setCity("hyd");
		o2.setNoOfItems(5);
		o2.setPincode(345324);
		o2.setGender("Male");
		o2.setPrice(900);
		
		OrdersData o3=new OrdersData();
		o3.setOrderId(43);
		o3.setCity("chennai");
		o3.setNoOfItems(5);
		o3.setPincode(345324);
		o3.setGender("Male");
		o3.setPrice(300);
		
		OrdersData o4=new OrdersData();
		o4.setOrderId(94);
		o4.setCity("ganagaram");
		o4.setNoOfItems(7);
		o4.setPincode(3424);
		o4.setGender("Male");
		o4.setPrice(670);
		
		List<OrdersData> l=new ArrayList();
		l.add(o4);
		l.add(o3);
		l.add(o2);
		l.add(o1);
		
		repo.saveAll(l);
		
	}
	// know applying sorting techniques
	// getting data based on orderid asendeing  by default ASCEnding if you are not passing any directions
	//actually my database table contains data like
	/*
	 * orderId 	city   		gender  noofItems pincode 	cost
	 * 	94		Ganagaram	Male	7			3424	670
		43		chennai		Male	5			345324	300
		85		HYD			Male	5			345324	900
		27		guntur		FeMale	57			3445324	200
		34		guntur		Male	5			345324	500
	 * 
	 */
	public void sortingDemo()
	{
		
		List< OrdersData> oid=repo.findAll(Sort.by("orderId"));
		oid.stream().forEach(System.out::println);
	}
	
	//after using above one data like Ascending order based on orderId
		/*	Orders [orderId=27, price=200.0, noOfItems=57, city=guntur, pincode=3445324, gender=FeMale]
			Orders [orderId=34, price=500.0, noOfItems=5, city=guntur, pincode=345324, gender=Male]
			Orders [orderId=43, price=300.0, noOfItems=5, city=chennai, pincode=345324, gender=Male]
			Orders [orderId=85, price=900.0, noOfItems=5, city=HYD, pincode=345324, gender=Male]
			Orders [orderId=94, price=670.0, noOfItems=7, city=Ganagaram, pincode=3424, gender=Male]

	*/
	
	//REQ 2) for example descending order
	public void sortingDemo1()
	{
		
		List< OrdersData> oid=repo.findAll(Sort.by(Direction.DESC,"orderId"));
		oid.stream().forEach(System.out::println);
	}
	/*
	Orders [orderId=94, price=670.0, noOfItems=7, city=Ganagaram, pincode=3424, gender=Male]
	Orders [orderId=85, price=900.0, noOfItems=5, city=HYD, pincode=345324, gender=Male]
	Orders [orderId=43, price=300.0, noOfItems=5, city=chennai, pincode=345324, gender=Male]
	Orders [orderId=34, price=500.0, noOfItems=5, city=guntur, pincode=345324, gender=Male]
	Orders [orderId=27, price=200.0, noOfItems=57, city=guntur, pincode=3445324, gender=FeMale]

	 */
	
	//REq3 for example passing two columns 
	public void sortingDemo2()
	{
		
		List< OrdersData> oid=repo.findAll(Sort.by(Direction.DESC,"city","orderId"));
		oid.stream().forEach(System.out::println);
		
	}
	
// first based on city desc orders follow by orderid
	/*
 Orders [orderId=85, price=900.0, noOfItems=5, city=hyd, pincode=345324, gender=Male]
Orders [orderId=34, price=500.0, noOfItems=5, city=guntur, pincode=345324, gender=Male]
Orders [orderId=27, price=200.0, noOfItems=57, city=guntur, pincode=3445324, gender=FeMale]
Orders [orderId=94, price=670.0, noOfItems=7, city=ganagaram, pincode=3424, gender=Male]
Orders [orderId=43, price=300.0, noOfItems=5, city=chennai, pincode=345324, gender=Male]
*/
	
	
	

}
