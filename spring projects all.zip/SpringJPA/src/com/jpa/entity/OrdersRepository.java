package com.jpa.entity;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OrdersRepository extends JpaRepository<Orders,Integer> {
	
	// THIS IS ALL CUSTOM METHODS BECOZ WE ARE CREATING IN JPA REPOSTIROY
	
	// craeting abstarct method for retrive city "hyd" by using jpa provided by "findBy" method internally
	
	// retrive city="hyd" may be getting 0 or more than 0 thats why taking list type for storing multiple values
	//and also passing parameter as first datatype of property and follwed by variable name
	List<Orders> findByCity(String city);
	// based on city and gender
	
	
	List<Orders> findByCityAndGender(String city,String gender);
	
	//based on city or gender { any one condition true its getting results} 
	List<Orders> findByCityOrGender(String city,String gender);

}
