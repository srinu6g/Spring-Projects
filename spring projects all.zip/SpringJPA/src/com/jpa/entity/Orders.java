package com.jpa.entity;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

// @Table (name="order") means jpa creates table name as order as per progrramer request
// for example am not taking name attribute that time 
//jpa take java class name or entity class name as database table name in this example am not 
@Entity
@Component
public class Orders {
	
	// orderid PK  price noOfItems  city  state pincode gender 
	// know takes orderId as primary key 
	//i want to change my database column name as per entity property
	// for ex my entity propert is = orderId but i want my DB column name as= oid 
	//how to do it simply using @Column(name="oid")
	@Id
	@Column(name="oid")
	private Integer orderId;
	// know in this am using @Column only meams database column  name as java class property name same
	// so price as it is my database column
	@Column(name="price")
	private double price;
	
	private int noOfItems;
	// in this am not writting @Column also no problem that time takes java propert as DBcolumn name same
	private String city;
	
	@Column
	private long pincode;
	@Column(name="gender")
	private String gender;

	
	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getNoOfItems() {
		return noOfItems;
	}

	public void setNoOfItems(int noOfItems) {
		this.noOfItems = noOfItems;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", price=" + price + ", noOfItems=" + noOfItems + ", city=" + city
				+ ", pincode=" + pincode + ", gender=" + gender + "]";
	}
	
	
	
	

}
