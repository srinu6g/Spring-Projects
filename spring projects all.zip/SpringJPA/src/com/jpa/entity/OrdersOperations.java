package com.jpa.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class OrdersOperations {
	@Autowired
	OrdersRepository repository;

	public void addRecordMore()
	{
		Orders order1=new Orders();
		order1.setOrderId(100);
		order1.setPrice(356.89);
		
		order1.setNoOfItems(4);

		
		
		order1.setCity("CHN");
		order1.setPincode(600078);
		order1.setGender("MALE");
		
		repository.save(order1);
		
	}
	public void addMoreRecords()
	{
		
		ArrayList<Orders> a=new ArrayList();
		Orders order1=new Orders();
		order1.setOrderId(103);
		order1.setPrice(400.89);
		
		order1.setNoOfItems(7);

		
		
		order1.setCity("CHN");
		order1.setPincode(600078);
		order1.setGender("FEMALE");
		
		
		Orders order2=new Orders();
		order2.setOrderId(104);
		order2.setPrice(1239.89);
		
		order2.setNoOfItems(7);

		
		
		order2.setCity("HYD");
		order2.setPincode(600078);
		order2.setGender("MALE");
		
		Orders order3=new Orders();
		order3.setOrderId(105);
		order3.setPrice(40056.89);
		
		order3.setNoOfItems(7);

		
		
		order3.setCity("BAN");
		order3.setPincode(600078);
		order3.setGender("FEMALE");
		
		
		Orders order4=new Orders();
		order4.setOrderId(102);
		order4.setPrice(400.89);
		
		order4.setNoOfItems(7);

		
		
		order4.setCity("CHN");
		order4.setPincode(600078);
		order4.setGender("FEMALE");
		
		
		Orders order5=new Orders();
		order5.setOrderId(107);
		order5.setPrice(1239.89);
	
		order5.setNoOfItems(7);

		
		
		order5.setCity("HYD");
		order5.setPincode(600078);
		order5.setGender("MALE");
		
		Orders order6=new Orders();
		order6.setOrderId(108);
		order6.setPrice(40056.89);
		
		order6.setNoOfItems(7);

		
		
		order6.setCity("BAN");
		order6.setPincode(600078);
		order6.setGender("FEMALE");

		
		a.add(order1);
		a.add(order2);
		a.add(order3);
		a.add(order4);
		a.add(order5);
		a.add(order6);
		
		
		repository.saveAll(List.of(order1,order2,order3,order4,order5,order6));
		





	}
	
	// based on primary key co;lumnyoucan delete that particular recrof because there is no duplicate
	public void deleteRecord()
	{
		repository.deleteById(100);
	}
	
	
	// dealing with non primary key columns how to retrive,delete,insert ......
	
	//getting orders information based on city hyd
	// there is no repo methods (pre defined methods) from jpa thats why first we create abstarct method in jpa repostiory
	
	public void getOrdersBasedCity(String city)
	{
		
		List<Orders> o1=repository.findByCity(city);
		for(Orders o2:o1)
		{
			System.out.println(o2);
		}
	}
	
	// getting city hyd and gender male both cases true giving results
	public void getCityAndGenderDetails()
	{
		List<Orders> o8 =	repository.findByCityAndGender("HYD","MALE");
		
		for(Orders o4:o8)
		{
			System.out.println(o4);
		}
	}
	
	//// getting city hyd or gender male both cases true giving results
	
	public void getCityOrGenderDetails()
	{
		List<Orders> o9 =	repository.findByCityOrGender("HYD","FEMALE");
		
		for(Orders o5:o9)
		{
			System.out.println(o5);
		}
	}
	
	// already 101 record is thre thats's why when calling save() in repo its considered as 
	//update method update orders set oid=101 where city="medapi"
	// this wiill update but remainnig data of same record getting default values
	
	//101	Medapi	null	0	0	0
	public void addOneMore()
	{
		Orders ord=new Orders();
		ord.setOrderId(101);
		ord.setCity("Medapi");
		
		repository.save(ord);
		
		
		
	}
	
	// to retrive primary key colums data by using findById()
	
	public void retriveData()
	{
		Optional<Orders> o =repository.findById(105);
		System.out.println(o.get());
	}
	public void retriveAllData()
	{
		List<Orders> l =repository.findAll();
		for(Orders l1:l)
		{
			System.out.println(l1);
		}
	}
	
	 
	
	
}
