package com.jpa.entity;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.jpa.Mani.SpringJpaConfiguration;

public class OrderMainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext container =new AnnotationConfigApplicationContext();
		container.register(SpringJpaConfiguration.class);
		container.refresh();
		
		OrdersOperations operations=container.getBean(OrdersOperations.class);
		//operations.addRecordMore();
		//operations.addMoreRecords();
	//	operations.deleteRecord();
		//operations.getOrdersBasedCity("HYD");
		//operations.getCityAndGenderDetails();
		//operations.getCityOrGenderDetails();
		//operations.addOneMore();
		//operations.retriveData();
		operations.retriveAllData();
	}

}
