package com.jpa.Mani;



import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringJpaDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(SpringJpaConfiguration.class);
		context.refresh();
		
		StudentOperations ops=(StudentOperations)context.getBean(StudentOperations.class);
		//ops.addDetails();
		//ops.deleteById();
		//ops.addDetailsMore();
		//ops.deleteAll();
		//ops.addMore();
		ops.getStudentData();
		
	}
	
	
}
