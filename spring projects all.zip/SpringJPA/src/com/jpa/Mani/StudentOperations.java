package com.jpa.Mani;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StudentOperations {
	//inject jpa repository intreface is parent of Studentrepository 
	//so all unimplemented methods available in StudentRepository also that one implemented in dynamically
	//by jpa framework internally in dynamic imple,mentation class
	@Autowired
	StudentRepository repo;
	public void addDetails()
	{
		//Create entity object
		Student student1=new Student();
		student1.setStudentID(106);
		student1.setStudentName("srinivas");
		student1.setAge(40);

		// Passing entity Object to repo
		// TO make Db operation
		// Inserting student details
		// call save(Entity) , then Internally I will take care of inserting data of
		// entity Object
		
		repo.save(student1);
		
	}
	// i want delete particular record in database
	public void deleteById()
	{
		repo.deleteById((long) 105);
	}
	
	// know i want add multiple records at a time
	
	public void addDetailsMore()
	{
		ArrayList<Student> a=new ArrayList();
		
		Student student2=new Student();
		student2.setStudentID(101);
		student2.setStudentName("rama");
		student2.setAge(20);
		a.add(student2);
		
		Student student3=new Student();
		student3.setStudentID(102);
		student3.setStudentName("sita");
		student3.setAge(25);
		a.add(student3);
		
		Student student4=new Student();
		student4.setStudentID(104);
		student4.setStudentName("brahma");
		student4.setAge(60);
		a.add(student4);
		
		repo.saveAll(List.of(student2,student3,student4));
		
		
		
	}
	
	// i want delete all
	
	public void deleteAll()
	{
		
		repo.deleteAll();
	}
	
	/// am trying to add multiple data again
	
		public void addMore()
		{
			List<Student> l1=new ArrayList();
			Student s1=new Student();
			s1.setStudentID(101);
			s1.setStudentName("rama");
			s1.setAge(20);
			
			l1.add(s1);
			
			Student s2=new Student();
			s2.setStudentID(102);
			s2.setStudentName("sita");
			s2.setAge(30);
			
			l1.add(s2);
			
			Student s3=new Student();
			s3.setStudentID(103);
			s3.setStudentName("lakshmana");
			s3.setAge(40);
			
			l1.add(s3);
			
			
			repo.saveAll(List.of(s1,s2,s3));
		}
		// know i want get data from database based on id,age name of student
		public void getStudentData() {
			Optional<Student> student = repo.findById(101l);

			Student stu = student.get();
			System.out.println(stu.getAge());
			System.out.println(stu.getStudentID());
			System.out.println(stu.getStudentName());
		}


}
