package com.jpa.Mani;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student,Long> {
	
	// internal default implmentation provide by SPring JPA 
		// to do Db operations 

}
