package com.jpa.jpql.practice;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ProductsRepository  extends JpaRepository<Products,Integer>{
	
	// know start jpql queries 
	// when ever we are working jpql first excute same query in sql what result you get
	//that one exactlygetting in java or not check then easily understand
	
// SQL : select pname from products;
	
	//JPQL : select p.ProductName from Products p;  p ->object refference Products p=new Products();
	@Query(value="select p from Products p")
	List<Products> allItems();
	
	//  i want pnames and cost of products 
	//SQL : select cost from products;
	//JPQL : select p.cost from Products p
	@Query(value="select p.cost from Products p")
	 List<Integer> gettingPnamesAndCost();
	
	
}
