package com.jpa.jpql.practice;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Products {
	
	@Id
	@Column(name="pid")
	int  productId;
	@Column(name="pname")
	String ProductName;
	int cost;
	int noOfItems;
		public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int getNoOfItems() {
		return noOfItems;
	}
	public void setNoOfItems(int noOfItems) {
		this.noOfItems = noOfItems;
	}
	@Override
	public String toString() {
		return "Products [productId=" + productId + ", ProductName=" + ProductName + ", cost=" + cost + ", noOfItems="
				+ noOfItems + "]";
	}
	
	
	

}
