package com.jpa.jpql.practice;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProductOpeartions {
	@Autowired
	ProductsRepository repo;
	
	public void addRecord()
	{
		
		Products p=new Products();
		p.setProductId(101);
		p.setProductName("Samsung");
		p.setNoOfItems(5);
		p.setCost(25000);
	
		repo.save(p);
	
	}
	
	public void addMoreRecords()
	{
		Products p1=new Products();
		p1.setProductId(102);
		p1.setProductName("Oneplus");
		p1.setNoOfItems(7);
		p1.setCost(30000);
		
		Products p2=new Products();
		p2.setProductId(103);
		p2.setProductName("IPhone");
		p2.setNoOfItems(9);
		p2.setCost(100000);
		
		Products p4=new Products();
		p4.setProductId(104);
		p4.setProductName("Redmi");
		p4.setNoOfItems(7);
		p4.setCost(50000);
		
		Products p5=new Products();
		p5.setProductId(105);
		p5.setProductName("Oneplus");
		p5.setNoOfItems(7);
		p5.setCost(30000);
		
		Products p6=new Products();
		p6.setProductId(106);
		p6.setProductName("IPhone");
		p6.setNoOfItems(9);
		p6.setCost(100000);
		
		Products p7=new Products();
		p7.setProductId(107);
		p7.setProductName("Redmi");
		p7.setNoOfItems(7);
		p7.setCost(50000);
		
		
		List<Products> l=new ArrayList<Products>();
		l.add(p5);
		l.add(p6);
		l.add(p7);
		l.add(p1);
		l.add(p2);
		l.add(p4);
		
		repo.saveAll(l);
		
		
	
	}
	
	/*public void addItems()
	{
		Products p=new Products();
		List<Products> s=repo.allItems();
		System.out.println(s.size());
		for(Products s1:s)
		{
			System.out.println(s1);
		}
		
		 
		for(Products s1:s)
		{
			System.out.println(s1.getProductName());
		}
		
		
	}*/
	
	public void getPnamesAndcost()
	{
		Products p=new Products();
		List<Integer> cost=	repo.gettingPnamesAndCost();
		for(int cost1:cost)
		{
			System.out.println(cost1);
		}
		
	}

}
