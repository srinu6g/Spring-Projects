package com.jpa.jpql.practice;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.jpa.Mani.SpringJpaConfiguration;

public class ProductsMainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(SpringJpaConfiguration.class);
		context.refresh();
		
		ProductOpeartions products=context.getBean(ProductOpeartions.class);
		//products.addRecord();
		//products.addMoreRecords();
		//products.addItems();
		products.getPnamesAndcost();
	}

}
