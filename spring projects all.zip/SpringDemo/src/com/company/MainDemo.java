package com.company;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BeanFactory factory=new FileSystemXmlApplicationContext("C:\\Users\\manik\\eclipse-workspace\\SpringDemo\\Demo.xml");
		
			Employee emp=(Employee)factory.getBean("e");
			
			/*Employee emp=(Employee)obj;
			System.out.println(emp);*/
			System.out.println("first Employee Details");
			
			System.out.println(emp);
			
			System.out.println(emp.getEmpId());
			System.out.println(emp.getEmpName());
			System.out.println(emp.getSal());
			
			
			// second object created for Employee class
			System.out.println("Second Employee Details");
			Employee e2=(Employee)factory.getBean("emp2");
			System.out.println(e2.getEmpId());
			System.out.println(e2.getEmpName());
			System.out.println(e2.getSal());

				}

}
