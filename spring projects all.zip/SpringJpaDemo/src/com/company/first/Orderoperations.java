package com.company.first;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Orderoperations {
	
	@Autowired
	OrderRepository repo;
	
	
	public void getOrderDetails()
	{
		Order o=new Order();
		o.setOrderId(101);
		o.setOrderName("iphone");
		o.setNoOfItems(6);
		o.setCost(45000);
		
		repo.save(o);
	}
	
	

}
