package com.company.first;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.annotation.AnnotationAwareOrderComparator;

public class OrderMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(SpringJpaConfiguration.class);
		context.refresh();
		
		Orderoperations ops= (Orderoperations)context.getBean(Orderoperations.class);
		ops.getOrderDetails();

	}

}
