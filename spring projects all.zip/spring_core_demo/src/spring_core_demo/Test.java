package spring_core_demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//System.out.println("Welcome to spring framework");
		
		BeanFactory factory=new FileSystemXmlApplicationContext("C:\\Users\\manik\\eclipse-workspace\\spring_core_demo\\demo.xml");
		Object obj=factory.getBean("e");
		
		Employee emp=(Employee)obj;
		System.out.println(obj);
		System.out.println(emp);
		System.out.println(emp.getEmpId());
		System.out.println(emp.getEmpName());
	// ADDrerss class information 	
		Address ass=(Address)factory.getBean("a");
		System.out.println(ass);
		System.out.println(ass.getCity());
		System.out.println(ass.getPincode());
		
	}

}
