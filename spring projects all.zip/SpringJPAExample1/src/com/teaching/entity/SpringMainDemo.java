package com.teaching.entity;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;



public class SpringMainDemo {

	public static void main(String[] args){
		// TODO Auto-generated method stub
		
		// create container object 
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(JpaConfiguration.class);
		context.refresh();
		
		// create bean id
		  try {
	            // create bean id
	            OrderOperationsexample ops = context.getBean(OrderOperationsexample.class);
	            System.out.println("Database connection done");
	        } catch (Exception e) {
	            // Handle any exceptions gracefully
	            e.printStackTrace(); // You can replace this with appropriate error handling
	        } finally {
	            // Close the application context
	            context.close();
	        }
		
		
		
		
		
		
	}

}
