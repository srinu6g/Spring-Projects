package com.teaching.entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class OrderOperationsexample {
	
	@Autowired
	OrderRepository repo;
	// all pre degined methods will be override automaticaly OrderRepository level
	
	
	

}
