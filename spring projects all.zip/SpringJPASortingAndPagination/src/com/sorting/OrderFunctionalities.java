package com.sorting;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;

@Component
public class OrderFunctionalities {
	
	@Autowired
	OrderRepository repo;
	
	
	public void addOrder()
	{
		Order o1=new Order();
		o1.setCity("HYD");
		o1.setGender("Male");
		o1.setNoOfItems(5);
		o1.setOrderId(101);
		o1.setPrice(450);
		o1.setPincode(345353);
		
		repo.save(o1);
		
	}
	public void multpleOrders()
	{
		Order o2=new Order();
		o2.setCity("HYD");
		o2.setGender("FeMale");
		o2.setNoOfItems(5);
		o2.setOrderId(56);
		o2.setPrice(450);
		o2.setPincode(345353);
		
		Order o3=new Order();
		o3.setCity("Chennai");
		o3.setGender("Male");
		o3.setNoOfItems(5);
		o3.setOrderId(89);
		o3.setPrice(450);
		o3.setPincode(345353);
		
		Order o4=new Order();
		o4.setCity("GUNTUR");
		o4.setGender("Male");
		o4.setNoOfItems(9);
		o4.setOrderId(23);
		o4.setPrice(45);
		o4.setPincode(345353);
		
		Order o5=new Order();
		o5.setCity("BANG");
		o5.setGender("Male");
		o5.setNoOfItems(8);
		o5.setOrderId(864);
		o5.setPrice(450);
		o5.setPincode(345353);
		
		
		List<Order> l1=Arrays.asList(o2,o3,o4,o5);
		
		repo.saveAll(l1);
		
	}
	public void addMultipleOrders()
	{
		Order o6=new Order();
		o6.setCity("Vizag");
		o6.setGender("FeMale");
		o6.setNoOfItems(5);
		o6.setOrderId(56);
		o6.setPrice(450);
		o6.setPincode(345353);
		
		Order o7=new Order();
		o7.setCity("NRT");
		o7.setGender("Male");
		o7.setNoOfItems(5);
		o7.setOrderId(89);
		o7.setPrice(450);
		o7.setPincode(345353);
		
		Order o8=new Order();
		o8.setCity("Vinukonda");
		o8.setGender("Male");
		o8.setNoOfItems(9);
		o8.setOrderId(23);
		o8.setPrice(45);
		o8.setPincode(345353);
		
		Order o9=new Order();
		o9.setCity("Ganagaram");
		o9.setGender("FeMale");
		o9.setNoOfItems(8);
		o9.setOrderId(864);
		o9.setPrice(450);
		o9.setPincode(345353);
		List<Order> l2=Arrays.asList(o6,o7,o8,o9);
		
		repo.saveAll(l2);
		
		
		
	}
	
	// sorting
	
	// default order asce
	 public void sortingBasedOnId()
	 {
		 
		 List<Order>  l2=repo.findAll(Sort.by("orderId"));
		 l2.stream().forEach(System.out::println);
	 }
	 //customized order desc
	 public void sortingBasedOnIdDesc()
	 {
		 
		 List<Order>  l3=repo.findAll(Sort.by(Direction.DESC,"orderId"));
		 l3.stream().forEach(System.out::println);
	 }
	 
	 public void sortingBasedOnCityDesc()
	 {
		 List<Order>  l4=repo.findAll(Sort.by(Direction.ASC,"city"));
		 l4.stream().forEach(System.out::println); 
		
	 }
	 
	 // pagination
	 
	 public void createPagination()
	 {
		 Page<Order>  p5= repo.findAll(PageRequest.of(1, 2));
		 List<Order> l5=p5.getContent();
		 l5.stream().forEach(System.out::println);
	 }
	 
	 
	 
	 

}
