package com.sorting;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Dress")
public class Order {
	@Id
	@Column(name="oid")
	private Integer orderId;
	// know in this am using @Column only meams database column  name as java class property name same
	// so price as it is my database column
	@Column(name="price")// if you don't write @Column annotation also it takes
	// by default java property name as table column name
	private double price;
	
	private int noOfItems;
	// in this am not writting @Column also no problem that time takes java propert as DBcolumn name same
	private String city;
	
	@Column
	private long pincode;
	@Column(name="gender")
	private String gender;

	
	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getNoOfItems() {
		return noOfItems;
	}

	public void setNoOfItems(int noOfItems) {
		this.noOfItems = noOfItems;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Orders [orderId=" + orderId + ", price=" + price + ", noOfItems=" + noOfItems + ", city=" + city
				+ ", pincode=" + pincode + ", gender=" + gender + "]";
	}
	
	


}
