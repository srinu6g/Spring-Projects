package com.sorting;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.sorting.config.SpringJpaConfiguration;

public class OrderMainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(SpringJpaConfiguration.class);
		context.refresh();
		
		
		OrderFunctionalities fun=	context.getBean(OrderFunctionalities.class);
		
		//fun.addOrder();
		//fun.multpleOrders();
		//fun.sortingBasedOnId();
		//fun.sortingBasedOnIdDesc();
		//fun.sortingBasedOnCityDesc();
		//fun.addMultipleOrders();
		fun.createPagination();
		
		
	}

}
