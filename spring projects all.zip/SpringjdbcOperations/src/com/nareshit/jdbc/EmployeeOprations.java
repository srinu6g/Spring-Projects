package com.nareshit.jdbc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class EmployeeOprations {
	
	
	@Autowired
	JdbcTemplate jdbctemplate;
	
	
	// insert into employee data using insert query
	public void addEmployye() {

		//jdbctemplate.update("insert into employee(eid,ename,salary) VALUES(101,'Suresh',35000)");
		//jdbctemplate.update("insert into employee(eid,ename,salary) VALUES(102,'hitesh',45000)");
		//jdbctemplate.update("insert into employee(eid,ename,salary) VALUES(103,'Mani',30000)");
		//System.out.println("One record inserted ");
		//jdbcTemplate.update("delete from employee where eid=1");
	}
	
	// Delete the data particular record
	
	/*public void deleteEmployee()
	{
		String query="delete from employee where eid =103";
		jdbctemplate.update(query);
		System.out.println("one record deleted");
	}*/
	
	//it retrive all data from given table
	
/*	public void allEmployeeDetails()
	{
		String query="select * from employee";
		List<Employee> allEmployees = jdbctemplate.query(query, new BeanPropertyRowMapper<Employee>(Employee.class));

		System.out.println("No of employees : " + allEmployees.size());
		
		allEmployees.stream().forEach(System.out::println);
		

	}*/
	
	//Passing data dynamically
	
	// Add Employee Details // Insertion of data
		// Data should be passed dynamicaly to query

		public void addEmployeeWithDynamicData(int eid, String ename, int salary) {

			String query = "insert into employee values(?,?,?)";

			int count = jdbctemplate.update(query, eid, ename, salary);

			System.out.println("No of Recoreds inserted : " + count);
		}
	
	
	//Deleteing enployee details dynamically
		
		
		public void addDeleteDetailsdynamically(int eid)
		{
			String query="delete from employee where eid=?";
			int c=jdbctemplate.update(query,eid);
			System.out.println("dynamically delete" +c);
		}

}
