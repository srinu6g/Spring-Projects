package com.nareshit.jdbc;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringJdbcDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(SpringJdbcConfiguration.class);
		context.refresh();
		EmployeeOprations emp=(EmployeeOprations)context.getBean(EmployeeOprations.class);
		
		//emp.addEmployye(); // call add employees metod for insert into a new record
		
		//emp.deleteEmployee();// delete a particular record
		
		//emp.allEmployeeDetails();// retrive all the data as objects from database 
		
		//emp.addEmployeeWithDynamicData(110,"Maddineni", 500);
		
		emp.addDeleteDetailsdynamically(105);

	}

}
