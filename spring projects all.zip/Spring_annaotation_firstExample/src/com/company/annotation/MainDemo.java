package com.company.annotation;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(BeanConfiguration.class);
		context.refresh();
		//Employee e= (Employee)context.getBean("emp2");
		//System.out.println(e);
		
		
		
		// Organization  class details 
		
		
		Organization org=context.getBean(Organization.class);
		System.out.println(org);
		Employee em=org.getEmployee();
		System.out.println(em);
		
		
	
	}

}
