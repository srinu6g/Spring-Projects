package com.company.annotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
@ComponentScan("com.*")
public class BeanConfiguration {
	
	
	// fisrt step without bean object 
	
	// now am creating bean objects
	@Bean("emp2")
	
	public Employee getEmployeeDetails2()
	{
		Employee e=new Employee();
		e.setEmpId(202);
		e.setEmpName("sharukhkan");
		return e;
	}
	
	@Bean("emp3")
	
	public Employee getEmployeeDetails3()
	{
		Employee e=new Employee();
		e.setEmpId(500);
		e.setEmpName("sitaramam");
		return e;
	}
	

		
}
