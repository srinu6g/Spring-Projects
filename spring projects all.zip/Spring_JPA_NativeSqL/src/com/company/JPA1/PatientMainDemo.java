package com.company.JPA1;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class PatientMainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(com.company.configuration.SpringJpaConfiguration.class);
		context.refresh();
		
		PatientOperations pa=context.getBean(PatientOperations.class);
		System.out.println("Succesfully");	
	}
}
