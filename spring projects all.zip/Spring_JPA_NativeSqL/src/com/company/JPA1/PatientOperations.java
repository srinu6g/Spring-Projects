package com.company.JPA1;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;

@Component
public class PatientOperations {
	
	@Autowired
	PatientRepository repo;
	
	
	/// Single patient details
	
		 
}
