package com.spring_mvc_firstExample.Controller3;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class Student {
	
	@RequestMapping("/s1/data")
	@ResponseBody
	public void getStudentDetails()
	{
		System.out.println("Student details are inserted into datatabvasvae");
	}

}
