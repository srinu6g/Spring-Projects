package com.spring_mvc_firstExample.Controller2;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class Orders {
	
	@RequestMapping("/order/phones")
	@ResponseBody
	public void GetOrderDetails()
	{
		System.out.println("am ordering iphone");
	}

}
