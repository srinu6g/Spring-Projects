package com.spring_mvc_firstExample.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller // if we declare the class as @Controller annotation that class
// called as Controller class/ controller layer
//@Controller  is derived from @Component annotation 
//@Controller  is a stereotype annotation
// what is meaning of @Component is if declare class as @Component making a class
//as bean class or component class then  bean objects created by spring container
// same way @Controller annaotion also same bean obects created by spring container
public class Payments {
	
	@RequestMapping("/user/gpay")
	@ResponseBody
	public void payments()
	{
		System.out.println("Hello welcome to spring mvc");
		System.out.println("Payments done via Google pay");
		
	}
	@RequestMapping("/user/phpay")
	@ResponseBody
	public void paymentsOnPhonepay()
	{
		System.out.println("Payments done via phone pay");
		
	}
	
	
	
	

}
