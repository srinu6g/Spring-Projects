package com.spring_mvc_firstExample.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

@ComponentScan("com.*")
@Configuration
@EnableWebMvc// this annotation equals to extends WebMvcConfigurationSupport this class
public class SpringMvcConfiguration extends WebMvcConfigurationSupport {
	

}
