package com.naresh.settetandconst;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SetterAndconstDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new 	AnnotationConfigApplicationContext();
		context.register(SetterAndConstructorConfiguration.class);
		context.refresh();
		System.out.println("*****EMp1 details *******");
		Employee emp1=(Employee)context.getBean("employee1");
		System.out.println(emp1);
		System.out.println(emp1.getEid());
		System.out.println(emp1.getEname());
		System.out.println(emp1.getSalary());
		
		
		System.out.println("*****EMp2 details *******");
		Employee emp2=(Employee)context.getBean("employee2");
		System.out.println(emp2);
		System.out.println(emp2.getEid());
		System.out.println(emp2.getEname());
		System.out.println(emp2.getSalary());
		
		
		System.out.println("*****EMp3 details *******");
		Employee emp3=(Employee)context.getBean("employee3");
		System.out.println(emp3);
		System.out.println(emp3.getEid());
		System.out.println(emp3.getEname());
		System.out.println(emp3.getSalary());
		
		System.out.println("------------------------------------");
		
		System.out.println("***company Details inside company emp2 details injects***");
		
		Company cmp=(Company)context.getBean(Company.class);
		System.out.println(cmp);
		System.out.println(cmp.getCname());
		System.out.println(cmp.getEmployee().getEid());
		System.out.println(cmp.getEmployee().getEname());
		System.out.println(cmp.getEmployee().getSalary());
		
		
		
		
				

	}

}
