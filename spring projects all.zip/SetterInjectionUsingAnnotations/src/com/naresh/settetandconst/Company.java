package com.naresh.settetandconst;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
public class Company {
	
	private String cname;
	//@Qualifier("employee2") not providing @qualifier annaotataon
	//same again amguity problem getting that one solve by using @Primary is used for we are
	//default object to the container
	
	@Autowired
	private Employee employee;
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

}
