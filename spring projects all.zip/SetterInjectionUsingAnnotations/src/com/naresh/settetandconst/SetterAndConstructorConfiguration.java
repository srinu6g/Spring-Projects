package com.naresh.settetandconst;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
@ComponentScan("com.naresh.settetandconst")
@Configuration
public class SetterAndConstructorConfiguration {
	@Bean("employee2")
	public Employee getEmployeeDetails()
	{
		Employee employee=new Employee();
		employee.setEid(101);
		employee.setEname("durga sir");
		employee.setSalary(23463.56);
		
		return employee;
	}
	@Primary
	@Bean("employee3")
	public Employee getEmployeeDetails3()
	{
		Employee employee=new Employee();
		employee.setEid(102);
		employee.setEname("nataraz sir");
		employee.setSalary(50000);
		
		return employee;
	}
	
}
