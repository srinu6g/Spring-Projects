package com.company.component;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.company.componentscan.Product;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(ConfigurationDemo.class);
	
		Employee emp=(Employee)context.getBean(Employee.class);
		System.out.println(emp);

		// with the help of bean id we can call product class
		Product product4=(Product)context.getBean("p4");
		System.out.println(product4);
		
		// with the help of component class in this time excepting one bean id but found two  p4,product 
		Product p1=(Product)context.getBean(Product.class);
		System.out.println(p1);
		
		

	}

	
}
