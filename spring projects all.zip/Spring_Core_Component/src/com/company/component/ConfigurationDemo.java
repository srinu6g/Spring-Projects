package com.company.component;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.company.componentscan.Product;

@Configuration
@ComponentScan("com.*")

public class ConfigurationDemo {
	
		@Bean("p4")
		Product getProductDetails()

		{
			Product p=new Product();
			p.setPid(101);
			p.setPname("Biryani");

			p.setPrice(200);
			return p;
			
		}
	

}
