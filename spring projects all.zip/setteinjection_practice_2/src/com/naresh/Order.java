package com.naresh;

import java.util.List;
import java.util.Map;

public class Order {
	
	private int orderId;
	private String orderName;
	private List<String> items;
	private Map<String,String> itemPrices;
	
	public Map<String, String> getItemPrices() {
		return itemPrices;
	}
	public void setItemPrices(Map<String, String> itemPrices) {
		this.itemPrices = itemPrices;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}
	public List<String> getItems() {
		return items;
	}
	public void setItems(List<String> items) {
		this.items = items;
	}
	
	

}
