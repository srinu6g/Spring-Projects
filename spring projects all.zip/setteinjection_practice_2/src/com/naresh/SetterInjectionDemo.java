package com.naresh;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;


public class SetterInjectionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// create container 
		
		BeanFactory factory=new FileSystemXmlApplicationContext("C:\\Users\\manik\\eclipse-workspace\\setteinjection_practice_2\\demo.xml");
		//List of data accecs
		//first order details using List 
	      Order ord=(Order)factory.getBean("first");
	      System.out.println(ord);
	      System.out.println(ord.getOrderId());
	      System.out.println(ord.getOrderName());
	      System.out.println(ord.getItems());
	      System.out.println(ord.getItems().size());
	      
	      
	      //Set of data accesss
	      // second order details using Set
	      System.out.println("Second Order Details");
	      Order ord2=(Order)factory.getBean("two");
	      System.out.println(ord2);
	      System.out.println(ord2.getOrderId());
	      System.out.println(ord2.getOrderName());
	      System.out.println(ord2.getItems());
	      System.out.println(ord2.getItems().size());
	      // am giving xml file lo 8 values but getting size of set = 6 because set don't allow duplicates
	     
	      //Map data access
	      System.out.println("Third order Detailss *........................*");
	      Order ord3=(Order)factory.getBean("third");
	      System.out.println(ord3);
	      System.out.println(ord3.getOrderId());
	      System.out.println(ord3.getItemPrices());
	      
	      
	      
	      
	      

	}

}
