package com.virtusa.naresh;

import java.util.List;

public class Maddineni {
	
	private int no;
	private List <String> order;
	//private List<Integer> id;
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public List<String> getOrder() {
		return order;
	}
	public void setOrder(List<String> order) {
		this.order = order;
	}
	
	
}
