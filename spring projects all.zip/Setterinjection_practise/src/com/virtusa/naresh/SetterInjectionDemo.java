package com.virtusa.naresh;

import org.springframework.beans.factory.*;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class SetterInjectionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*BeanFactory factory=new FileSystemXmlApplicationContext("C:\\Users\\manik\\eclipse-workspace\\Setterinjection_practise\\beans.xml");
	Hitesh h1 = (Hitesh)factory.getBean("hitesh");
	System.out.println("Hello");
	System.out.println(h1.getEmpid());
	System.out.println(h1.getName());*/
	
	System.out.println("Maddinei class details");
	
	BeanFactory factory=new FileSystemXmlApplicationContext("C:\\Users\\manik\\eclipse-workspace\\Setterinjection_practise\\beans.xml");
	Maddineni m1 = (Maddineni)factory.getBean("obj");
	System.out.println(m1.getNo());
	
	System.out.println(m1.getOrder());
	

	
	}

}
