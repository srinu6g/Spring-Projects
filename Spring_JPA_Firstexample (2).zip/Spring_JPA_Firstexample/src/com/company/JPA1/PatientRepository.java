package com.company.JPA1;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.transaction.Transactional;

@Repository
public interface PatientRepository extends JpaRepository<Patient,String>
{
	
	/*
	//Requirement: Get Details of Patients by Age i.e. Single Column
//	public int findByPatientAge(int patientAge);
	
	//List<Patient> findBypatientAge(int age);
	
	//Requirement: Fetch Data with Age and Gender Columns. 
	//• Age is 24
	//• Gender is Female

	List<Patient> findBypatientAgeAndGender(int age,String gender);
	
	// patientAge
	
	// perform sorting pre defined method available findALL()*/
	
	// now working on native sql queries
/*	@Query(value = "select * from patient" ,nativeQuery = true)
	List<Patient> getPatient();
	
	// getting patient details based on email
	
	@Query(value = "select * from patient where email=?1" ,nativeQuery = true)
	List<Patient> getPatientEmialDetails(String email);
		
	// based on age and gender getting patient details
	
	@Query(value = "select * from patient where email=?1 and gender=?2" ,nativeQuery = true)
	List<Patient> getPatientDetailsByEmailandGender(String email,String gender);
	
	
	@Query(value="select * from patient where age=?1" ,nativeQuery = true)
	List<Patient> getPatientAgeDetails(int age);
	// now my query is getting patient age details who ever age is 24 and gender is male
	
	@Query(value="select * from patient where age=?1 and gender=?2" ,nativeQuery = true)
	List<Patient> getPatientAgeGenderDetails(int age,String gender); */
	
	
	
	// Parameter query based
	
	@Query(value="select * from patient where age=:patientAge" ,nativeQuery = true)
	List<Patient> getPatientAgeDetails(@Param("patientAge")int age);
	
	
	@Query(value="select * from patient where age=:patientAge and gender=:gender" ,nativeQuery = true)
	List<Patient> getPatientAgeGenderDetails(@Param("patientAge")int age,@Param("gender")String gender);
	
	
	// insert data by using named paaramter
	
	// @Transactional annotation is used for DMLqueries
	//@Transactional
	/*@Modifying
	@Query(value="INSERT INTO patient(:patientName,:patientAge,gender,:email,:mobileNumber) VALUES(?,?,?,?,?)",nativeQuery = true)
	public void addPatient(@Param("patientName") String name,
							@Param("patientAge") int age,
							@Param("gender") String gender,
							@Param("email") String email,
							@Param("mobileNumber") int number
			);*/
	
	
	// know getteing all the patient details by using JPQL
	
	@Query(value="SELECT p FROM Patient p")
	List<Patient> getAllDetails();
	// what p means is a object refference Patient p=new Patient();
	
	// getting all patientnames 
	@Query(value="SELECT p.patientName from Patient p")
	List<String> getAllPatientNames();
	
	// getting all patientemailid
		@Query(value="SELECT p.email from Patient p")
		List<String> getAllPatientEmails();
		
		
	
}

