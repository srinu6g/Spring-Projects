package com.company.JPA1;

import java.util.Optional;

import org.hibernate.mapping.List;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.company.JPA.SpringJpaConfiguration;

public class PatientMainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(SpringJpaConfiguration.class);
		context.refresh();
		
		PatientOperations pa=context.getBean(PatientOperations.class);
		//System.out.println(pa.getPatientDetails());
	// System.out.println(pa.getPatientEmailDetails("Anu@gmail.com"));
		
	// if data is present in database it will return else it will give []	
		
		//System.out.println(pa.getPatientDetailsEmailAndGender("Raitu@gmail.com", "Female"));
		
		//System.out.println(pa.getPatientAgeDetails());
		
		//System.out.println(pa.getPatientAgeGenderDetails());
		
	/* working on named paramter query based*/
		
		//System.out.println(pa.getPatientAgeDetails());
		
		//System.out.println(pa.getPatientAgeGenderDetails());
		
	/*	pa.addPatientDetails("raja",34,"Male","raja@gmail.com",45366);
		System.out.println("record addded successfully"); */
		
		
		//System.out.println(pa.getPatientDetailsByEmail());
		
		//pa.getPatientDataBasedOnPagination();
		
		//pa.getPageDetails();
		//pa.getPageDetails2();
		
		//System.out.println(pa.getData());
		
		//System.out.println(pa.getPatientNameSDetails());
		
		System.out.println(pa.getPatientEmailsDetails());
	}

}
