package com.company.JPA1;

import java.awt.print.Pageable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;

@Component
public class PatientOperations {
	
	@Autowired
	PatientRepository repo;
	
	
	
/*	/// Single patient details
	
	public void patientDetails()
	{
		Patient p=new Patient();
		p.setEmail("sriivas@gmail.com");
		p.setGender("Male");
		p.setMobileNumber(45639495);
		p.setPatientAge(24);
		p.setPatientName("srini");
		
		
		repo.save(p);
		
		
	}
	
	// Multiple patient details 
	public void addMorePatients()
	{
		Patient p1=new Patient();
		p1.setEmail("sriivas@gmail.com");
		p1.setGender("Male");
		p1.setMobileNumber(45639495);
		p1.setPatientAge(24);
		p1.setPatientName("srini");
		
		
		Patient p2=new Patient();
		p2.setEmail("mani@gmail.com");
		p2.setGender("Male");
		p2.setMobileNumber(8979495);
		p2.setPatientAge(22);
		p2.setPatientName("mani");
		
		Patient p3=new Patient();
		p3.setEmail("hitesh@gmail.com");
		p3.setGender("Male");
		p3.setMobileNumber(9663081);
		p3.setPatientAge(25);
		p3.setPatientName("hitesh");
		
		
		Patient p4=new Patient();
		p4.setEmail("ajay@gmail.com");
		p4.setGender("FEMale");
		p4.setMobileNumber(964095);
		p4.setPatientAge(24);
		p4.setPatientName("ajay");
		
		Patient p5=new Patient();
		p5.setEmail("Raitu@gmail.com");
		p5.setGender("Male");
		p5.setMobileNumber(45639495);
		p5.setPatientAge(24);
		p5.setPatientName("Raitu");
		
		
		Patient p6=new Patient();
		p6.setEmail("swathi@gmail.com");
		p6.setGender("Female");
		p6.setMobileNumber(8979495);
		p6.setPatientAge(22);
		p6.setPatientName("swathi");
		
		Patient p7=new Patient();
		p7.setEmail("malli@gmail.com");
		p7.setGender("Female");
		p7.setMobileNumber(9663081);
		p7.setPatientAge(25);
		p7.setPatientName("Malli");
		
		
		Patient p8=new Patient();
		p8.setEmail("Anu@gmail.com");
		p8.setGender("FEMale");
		p8.setMobileNumber(964095);
		p8.setPatientAge(24);
		p8.setPatientName("anu");
		
		Patient p9=new Patient();
		p9.setEmail("Anu@gmail.com");
		p9.setGender("FEMale");
		p9.setMobileNumber(964095);
		p9.setPatientAge(24);
		p9.setPatientName("anu");
		
		
		List<Patient> l1=new ArrayList();
		l1.add(p1);
		l1.add(p2);
		
		l1.add(p3);
		
		l1.add(p4);
		l1.add(p5);
		l1.add(p6);
		l1.add(p7);
		l1.add(p8);
		l1.add(p9);
		
		
		repo.saveAll(l1);
		
		
	}
	
	// update patient detalis
	
	
	public void updatePatientDetails()
	{
		
		Patient p4=new Patient();
		p4.setEmail("ajay@gmail.com");
		p4.setGender("Male");
		p4.setMobileNumber(964095);
		p4.setPatientAge(24);
		p4.setPatientName("ajay");
		
		
		repo.save(p4);
		
	}
	
	
	// retrive the data 
	
	public Patient getPatentDetails(String email)
	{
		return repo.findById(email).get();
	}
	
	// delete single record
	
	 public void deletePatientDetails(String email)
	 {
		 repo.deleteById(email);
	 }
	
	//Requirement: Get Details of Patients by Age i.e. Single Column
	 
	/* public List<Patient> fetchPatientAgeDetails(int age)
	 
	 {
		return repo.findBypatientAge(age);
	 }*/
	 
	//Requirement: Fetch Data with Age and Gender Columns. 
		//• Age is 24
		//• Gender is Female
	 
/*	 public List<Patient> fetchPatientAgeAndGender(int age,String gender)
	 {
		 
		 return repo.findBypatientAgeAndGender(age, gender);
	 }
	 
	 //**perform sorting 
	 
	 public List<Patient> sortingByEmail(String email)
	 {
		 return repo.findAll(Sort.by("email"));
	 }
	 
	 // based on patientName
	 
	 public List<Patient> sortingByPatientName()
	 {
		 List<Patient> l=repo.findAll(Sort.by("patientName"));
		 return l;
	 }
	 // I want descending order based on patientName
	 
	 public List<Patient> sortingByPatientNameDesc()
	 {
		 List<Patient> l=repo.findAll(Sort.by(Direction.DESC,"patientName"));
		 return l;
	 }
	 
	 public List<Patient> sortingByPatientNameDescending()
	 {
		List<Patient> l2= repo.findAll(Sort.by(Direction.ASC,"patientName"));
		return l2;
	 }
	 // multiple columns pass 
	 public List<Patient> sortingByPatientNameAndAgeDescending()
	 {
		List<Patient> l3= repo.findAll(Sort.by(Direction.DESC,"patientName","email"));
		return l3;
	 }*/
	
	 // ** pagenation ***// */
	 
	// performing native SQL
	
	/*public List<Patient> getPatientDetails()
	{
		return repo.getPatient();
	}
	
	public List<Patient> getPatientEmailDetails(String email)
	{
		return repo.getPatientEmialDetails(email);
	}
	public List<Patient> getPatientDetailsEmailAndGender(String email,String gender)
	{
		return repo.getPatientDetailsByEmailandGender(email, gender);
	}
	public List<Patient> getPatientAgeDetails()
	{
		return repo.getPatientAgeDetails(24);
	}
	public List<Patient> getPatientAgeGenderDetails()
	{
		return repo.getPatientAgeGenderDetails(24,"Male");
	}*/
	
	/*public List<Patient> getPatientAgeDetails()
	{
		return repo.getPatientAgeDetails(24);
	}
	
	public List<Patient> getPatientAgeGenderDetails()
	{
		return repo.getPatientAgeGenderDetails(24,"Male");
	}*/
	/*public void addPatientDetails(String name,int age,String gender,String email,int number)
	{
		repo.addPatient(name,age,gender,email,number);
	}*/
	
	public List<Patient> getPatientDetailsByEmail()
	{
		      List<Patient> p1= repo.findAll(Sort.by(Direction.DESC,"email","gender"));
		      return p1;
	}
	
	/* Pagination */
	
	public void getPatientDataBasedOnPagination()
	{
		Page<Patient> p=repo.findAll(PageRequest.of(0, 3));
		List<Patient> l = p.getContent();
		l.stream().forEach(System.out::println);
	}
	
	// know i want each pagination having 3 records getting all paggenations
	//means for example in my database table contain 400 records now i want 3 records for each pagination
	//so how many pagination getting (400/3)= 134 paginations getting 
	
	public void getPageDetails()
	{
		
		PageRequest req=PageRequest.of(2, 4);
		List<Patient> l2=repo.findAll(req).getContent();
		l2.stream().forEach(System.out::println);
		
	}
	 // performing pagination along with sorting
	
	public void getPageDetails2()
	{
		
	PageRequest req=PageRequest.of(1, 4,Sort.by(Direction.DESC,"email"));
		List<Patient> l4=repo.findAll(req).getContent();
		l4.stream().forEach(System.out::println);
		
	}
	
	// ********* JPQL  ***************** //
	
	public List<Patient> getData()
	{
		Patient p=new Patient();
		return repo.getAllDetails();
		
	}
	// getting all patient namesd 
	
	public List<String> getPatientNameSDetails()
	{
		Patient p=new Patient();
		return repo.getAllPatientNames();
		
	}
	
	public List<String> getPatientEmailsDetails()
	{
		Patient p=new Patient();
		return repo.getAllPatientEmails();
		
	}
	
}
