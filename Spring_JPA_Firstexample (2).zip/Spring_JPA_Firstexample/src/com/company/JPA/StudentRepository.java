package com.company.JPA;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Integer> {
	
	
	// Student is a java class name and id of column in java class return type Integer

	// custom Query methods 
	
	// Req1 :: getting data/record by using Studentname
	
	
	//public List<Student> findByjava proprtyname(parameter return type)
	public List<Student> findBystudentName(String sname);
	
	// Req2 :: getting data/record by using age

		public List<Student> findByage(int age);
		
		
		// req3  i want to retrive/getting based on age and sname
		
		public List<Student> findByStudentNameAndAge(String sname,int age);	
		
		
		//nativeQueey,JPQL
			
}
