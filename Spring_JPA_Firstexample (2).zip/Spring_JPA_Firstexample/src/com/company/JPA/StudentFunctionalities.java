package com.company.JPA;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StudentFunctionalities {
	
	@Autowired
	StudentRepository repo;
	
	//REq 1 ::  Add one student deatils
	
	/*public void addStudent()
	{
		Student s1=new Student();
		
			s1.setAge(25);
			s1.setCourse("java");
			s1.setStudentId(101);
			s1.setStudentName("srinivas");
			
			repo.save(s1);
		
	}
	
	// Req i want multiple student data at a time 10 student
	
	public void AddMoreStudentDetails()
	{
		Student s2=new Student();
		s2.setAge(24);
		s2.setCourse("Spring");
		s2.setStudentId(102);
		s2.setStudentName("Hitesh");
		
		Student s3=new Student();
		s3.setAge(29);
		s3.setCourse("SpringBoot");
		s3.setStudentId(103);
		s3.setStudentName("Lakshmi");
		
		Student s4=new Student();
		s4.setAge(24);
		s4.setCourse("HTML");
		s4.setStudentId(105);
		s4.setStudentName("Anu");
		
		Student s5=new Student();
		s5.setAge(45);
		s5.setCourse("SQL");
		s5.setStudentId(192);
		s5.setStudentName("rajavani");
		
		Student s6=new Student();
		s6.setAge(24);
		s6.setCourse("Oracle");
		s6.setStudentId(120);
		s6.setStudentName("preeti");
		
		
		List<Student> l2=new ArrayList<>();
		l2.add(s2);
		l2.add(s3);
		l2.add(s4);
		l2.add(s5);
		l2.add(s6);	
		
		repo.saveAll(l2);
	} 
	
	// REq 3 I  want to update my sid is 192 to 105
	
	public void updateStudent()
	{
		
		Student s6=new Student();
		s6.setAge(24);
		s6.setCourse("English");
		s6.setStudentId(109);
		s6.setStudentName("Deva");
		
		repo.save(s6)
;		
	}
	
	// fetchig the records
	
	// based on primary key columns and non primary key columns 
	
	public Student fetchingStudentDetails()
	{
		return repo.findById(102).get();
	}
	
	// deleting a record
	
	public void deleteRecord()
	{
		repo.deleteById(109);
	}*/
	
	
	// now talking about custom query parameters 
	// we can achive/retrive dattabase information via non primary key columns 
	
	public List<Student> gettingDetailsbasedOnStudentName()
	{
		return repo.findBystudentName("Hitesh");
	}
	

	public List<Student> gettingDetailsbasedOnAge()
	{
		return repo.findByage(24);
	}
	// // req3  i want to retrive/getting based on age and sname
	
	
	public List<Student> gettingDetailsbasedOnStudentNameAndage()
	{
		return repo.findByStudentNameAndAge("preeti",24);
	}
	
	
	
	

}
