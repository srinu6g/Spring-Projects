package com.company.JPA;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class SpringJpaDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//create container 
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.register(SpringJpaConfiguration.class);
		context.refresh();
		
		StudentFunctionalities stu1=context.getBean(StudentFunctionalities.class);
		//stu1.addStudent();
		//stu1.AddMoreStudentDetails();
		//stu1.updateStudent();
		//System.out.println(stu1.deleteRecord());
		
		//stu1.deleteRecord();
		//System.out.println(stu1.gettingDetailsbasedOnStudentName());
		//System.out.println(stu1.gettingDetailsbasedOnAge());
		System.out.println(stu1.gettingDetailsbasedOnStudentNameAndage());
		
	}

}
