package com.rest.services.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rest.services.dto.UserDetails;
import com.rest.services.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	UserService userService;
	
	
	@PostMapping("/user/create")
	@ResponseBody// converting java to json and json to java
	public String createUser(@RequestBody UserDetails req)
	{
	System.out.println("Your req come from user details class as a requet claa frontend"+req);
	// this given below line
	//indictes req forward from controller to service layer 
	String res=userService.createUser(req);
		
		
		return res;
		
		
		
	}
	
	public String loadDeteails()
	{
		return null;
	}
	
	

}
