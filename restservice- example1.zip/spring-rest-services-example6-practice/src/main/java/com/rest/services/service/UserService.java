package com.rest.services.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rest.services.dto.UserDetails;
import com.rest.services.entity.UserInformation;
import com.rest.services.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository repo;
	

	public String createUser(UserDetails req) {
		// TODO Auto-generated method stub
		
		UserInformation info=new UserInformation();
		info.setEmail(req.getEmail());
		info.setContact(req.getContact());
		info.setGender(req.getGender());
		info.setPwd(req.getPwd());
		info.setUname(req.getUname());
		
		repo.save(info);
		
		return "success";
	}
	
	
	
	
	

}
