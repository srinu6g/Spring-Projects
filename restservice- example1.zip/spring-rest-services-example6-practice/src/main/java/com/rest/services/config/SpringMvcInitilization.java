package com.rest.services.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

//import com.spring.hello.SpringMvcConfiguration;

public class SpringMvcInitilization extends AbstractAnnotationConfigDispatcherServletInitializer {

	@Override
	protected Class<?>[] getRootConfigClasses() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		// TODO Auto-generated method stub
		return new Class[] { SpringMvcConfiguration.class };// this line said that what ever configuration classes are there those all
		// classes we configure ex: Any no of configuration classes no problem becoz it is a String []
		//return new Class[] { SpringMvcConfiguration.class,SpringMvcConfiguration2.class,SpringMvcConfiguration3.class,};
	}

	@Override
	protected String[] getServletMappings() {
		// TODO Auto-generated method stub
		String[] allowedURIs = {"/"}; // this line tells that  it allows any url from client or browser
	// Any url come from browser or client first url/request taken by dispatcherservelt
	// thats why its extends 	extends AbstractAnnotationConfigDispatcherServletInitializer {

		return allowedURIs;
	}

}
